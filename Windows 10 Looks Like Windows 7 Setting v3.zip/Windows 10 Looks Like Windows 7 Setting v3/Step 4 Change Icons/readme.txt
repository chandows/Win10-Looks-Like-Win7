copy the "icon" file to C:\

appy disk.reg and folder.reg

your DVD-ROM drive should be letter Y
your RAM Disk drive should be letter Z