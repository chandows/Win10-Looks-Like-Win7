copy the "icon" file to C:\

appy disk.reg and folder.reg

your ROM drive should be letter Y
your RAM drive should be letter Z